from django.contrib import admin

# Register your models here.
admin.site.site_header = 'Courier Management System'
admin.site.index_title = 'ADMIN'