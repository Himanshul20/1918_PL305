from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.forms import inlineformset_factory
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group

# Create your views here.
from .models import *
from .forms import BookingForm, CreateUserForm

from .decorators import unauthenticated_user, allowed_users, admin_only


@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='staff')
            user.groups.add(group)

            messages.success(request, 'Account was created for ' + username)

            return redirect('staff_login')

    context = {'form': form}
    return render(request, 'register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'staff_login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('/staff_login')


@login_required(login_url='login')
@admin_only
def home(request):
    form = BookingForm.bjects.all()

    context = {'form': form}

    return render(request, 'accounts/dashboard.html', context)


def userPage(request):
    context = {}
    return render(request, 'user_dashboard.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin', 'staff'])
def staff(request):

    book = Booking.objects.all()
    return render(request, 'staff_dashboard.html', {'sbook': book})



def Booked(request,id=None):
    current_user = request.user
    user_id = current_user.id
    sql = "SELECT * FROM couriersys_booking,auth_user where couriersys_booking.user_id=auth_user.id and couriersys_booking.user_id='%s' " % user_id
    posts = Booking.objects.raw(sql)[:5]

    return render(request, 'ShowBooked.html', {'sbook': posts})


@login_required(login_url='staff_login')
@allowed_users(allowed_roles=['admin', 'staff'])
def book(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            try:

                form.save()
                messages.success(request, 'Form submission successful')


                return redirect('/booking')
            except:
                pass
    else:
        form = BookingForm()
    return render(request, 'BookingForm.html', {'form': form})


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateOrder(request, pk):
    order = Order.objects.get(id=pk)
    form = OrderForm(instance=order)

    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form': form}
    return render(request, 'accounts/order_form.html', context)


def delete_items(request, pk):
    set = Booking.objects.get(id=pk)
    if request.method == 'POST':
        set.delete()
        return redirect('/Booked')
    context = {
        'set': set,
    }
    return render(request, 'delete_shipment.html', context)


def view_PDF(request, id=None):
    booking = get_object_or_404(Booking, id=id)
    form = Booking.objects.all()
    context = {
        "company": {
            "name": "Fast Courier Services & Cargo",
            "address": "67542 Jeru, Chatsworth, CA 456987, india",
            "phone": "(818) XXX XXXX",
            "email": "contact@ifastservice.com",
        },
        "invoice_id": booking.AWB,
        "invoice_total": booking.cost,
        "customer": booking.sfname,
        "scity": booking.scity,
        "sstate": booking.sstate,
        "spostal": booking.spostal,
        "reciver": booking.Rfname,
        "rcity": booking.Rcity,
        "rstate": booking.Rstate,

        "type": booking.shiptype,
        "weight": booking.weight,

        "date": booking.created_at,
        "due_date": booking.updated_at,
        "billing_address1": booking.Rstreetadd,
        "billing_address2": booking.Rstreetadd2,
        "form": form,
    }
    return render(request, 'pdfinvoice.html', context)

