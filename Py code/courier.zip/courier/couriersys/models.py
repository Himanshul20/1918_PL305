from django.contrib.auth.models import User
from django.db import models
from phonenumber_field.modelfields import PhoneNumberField

# Create your models here.
SHIP_TYPE = (
    ('type', 'TYPE'),
    ('parcel', 'PARCEL'),
    ('document', 'DOCUMENT'),

)

STATE = (
    ('st', 'STATE'),
    ('KA', 'Karnataka'),
    ('AP', 'Andhra Pradesh'),
    ('KL', 'Kerala'),
    ('TN', 'Tamil Nadu'),
    ('MH', 'Maharashtra'),
    ('UP', 'Uttar Pradesh'),
    ('GA', 'Goa'),
    ('GJ', 'Gujarat'),
    ('RJ', 'Rajasthan'),
    ('HP', 'Himachal Pradesh'),
    ('JK', 'Jammu and Kashmir'),
    ('TG', 'Telangana'),
    ('AR', 'Arunachal Pradesh'),
    ('AS', 'Assam'),
    ('BR', 'Bihar'),
    ('CG', 'Chattisgarh'),
    ('HR', 'Haryana'),
    ('JH', 'Jharkhand'),
    ('MP', 'Madhya Pradesh'),
    ('MN', 'Manipur'),
    ('ML', 'Meghalaya'),
    ('MZ', 'Mizoram'),
    ('NL', 'Nagaland'),
    ('OR', 'Orissa'),
    ('PB', 'Punjab'),
    ('SK', 'Sikkim'),
    ('TR', 'Tripura'),
    ('UA', 'Uttarakhand'),
    ('WB', 'West Bengal'),

)


class Booking(models.Model):
    AWB = models.IntegerField(unique=True)
    sfname = models.CharField(max_length=20)
    slname = models.CharField(max_length=20)
    streetadd = models.CharField(max_length=30)
    streetadd2 = models.CharField(max_length=30)
    scity = models.CharField(max_length=20)
    sstate = models.CharField(max_length=20, choices=STATE, default='st')
    scountry = models.CharField(max_length=20, default='INDIA')
    spostal = models.IntegerField()
    smobile = models.BigIntegerField()
    Rfname = models.CharField(max_length=20)
    Rlname = models.CharField(max_length=20)
    Rstreetadd = models.CharField(max_length=30)
    Rstreetadd2 = models.CharField(max_length=30)
    Rcity = models.CharField(max_length=20)
    Rstate = models.CharField(max_length=20, choices=STATE, default='st')
    Rcountry = models.CharField(max_length=20, default='INDIA')
    Rpostal = models.IntegerField()
    Rmobile = models.BigIntegerField()
    weight = models.FloatField()
    shiptype = models.CharField(max_length=10, choices=SHIP_TYPE, default='type')
    cost = models.FloatField()
    user = models.ForeignKey(User, on_delete=None)

    class Meta:
        db_table = "couriersys_booking"
