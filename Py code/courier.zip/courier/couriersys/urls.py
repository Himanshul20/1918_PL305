from . import views
from django.urls import path

urlpatterns = [
    path('register/', views.registerPage, name="register"),
    path('staff_login/', views.loginPage, name="staff_login"),

    path('logout/', views.logoutUser, name="logout"),
    path('booking/', views.book, name='BookingForm'),
    path('', views.userPage, name="user-page"),
    path('Booked', views.Booked, name="Booked"),
    # path('invoice', views.invoice, name="Booked"),
    path('staff_login/staff', views.staff, name='home'),
    # path('delete', views.delete_booking, name='delete'),
    path('delete_items/<str:pk>/', views.delete_items, name="delete_items"),
    path('invoice-detail/<id>', views.view_PDF, name='invoice-detail'),

]
