from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group

# Create your views here.
from .models import *
from .forms import BookingForm, CreateUserForm

from .decorators import unauthenticated_user, allowed_users, admin_only


@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='staff')
            user.groups.add(group)

            messages.success(request, 'Account was created for ' + username)

            return redirect('login')

    context = {'form': form}
    return render(request, 'register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'staff_login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('/staff_login')


@login_required(login_url='login')
@admin_only
def home(request):
    form = BookingForm.bjects.all()

    context = {'form': form}

    return render(request, 'accounts/dashboard.html', context)


def userPage(request):
    context = {}
    return render(request, 'user_dashboard.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin', 'staff'])
def staff(request):
    form = Booking.objects.all()

    context = {'form': form}

    return render(request, 'staff_dashboard.html', context)


@login_required(login_url='staff_login')
@allowed_users(allowed_roles=['admin','staff'])
def book(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return HttpResponse("<h1 style='color:green;'> Shipment Booked Successfully !</h>")
            except:
                pass
    else:
        form = BookingForm()
    return render(request, 'BookingForm.html', {'form': form})


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateOrder(request, pk):
    order = Order.objects.get(id=pk)
    form = OrderForm(instance=order)

    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form': form}
    return render(request, 'accounts/order_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteOrder(request, pk):
    order = Order.objects.get(id=pk)
    if request.method == "POST":
        order.delete()
        return redirect('/')

    context = {'item': order}
    return render(request, 'accounts/delete.html', context)



def test(request):
    if request.method == 'POST':
        form = Test(request.POST)
        if form.is_valid():
            try:
                form.save()
                return HttpResponse("<h1 style='color:green;'> Shipment Booked Successfully !</h>")
            except:
                pass
    else:
        form = Test()
    return render(request, 'test.html', {'form': form})