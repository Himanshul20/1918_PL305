from . import views
from django.urls import path


urlpatterns = [
    path('register/', views.registerPage, name="register"),
    path('staff_login/', views.loginPage, name="staff_login"),
  #  path('admin_login/', views.loginPage, name="admin_login"),
    path('logout/', views.logoutUser, name="logout"),
    path('booking', views.book, name='BookingForm'),
    path('', views.userPage, name="user-page"),

    path('staff_login/staff', views.staff, name='home'),

]
