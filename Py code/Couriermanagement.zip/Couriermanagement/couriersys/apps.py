from django.apps import AppConfig


class CouriersysConfig(AppConfig):
    name = 'couriersys'
