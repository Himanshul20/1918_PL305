$(document).ready(() => {
  // SideNav Button Initialization
  $(".button-collapse").sideNav2();
  // SideNav Scrollbar Initialization
  var sideNavScrollbar = document.querySelector('.custom-scrollbar');
  var ps = new PerfectScrollbar(sideNavScrollbar);
});